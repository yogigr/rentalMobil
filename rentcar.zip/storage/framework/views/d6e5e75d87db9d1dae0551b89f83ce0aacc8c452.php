<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-sm-12">
			<div class="box">
				<div class="box-header">
					<div class="row">
						<div class="col-sm-6">
							Statistik Pengunjung
						</div>
						<div class="col-sm-6 text-right">
							Jumlah Pengunjung: <strong><?php echo e(Visitor::count()); ?></strong>,
							Jumlah Click: <strong><?php echo e(Visitor::clicks()); ?></strong>
						</div>
					</div>
				</div>
				<div class="box-body table-responsive no-padding">
					<table class="table table-bordered table-striped table-hover">
						<thead>
							<tr>
								<th>IP Address</th>
								<th>Negara</th>
								<th>Jumlah Click</th>
							</tr>
						</thead>
						<tbody>
							<?php if(Visitor::count() > 0): ?>
							<?php foreach(Visitor::all() as $visitor): ?>
								<tr>
									<td><?php echo e($visitor->ip); ?></td>
									<td><?php echo e(is_null($visitor->country) ? '-' : $visitor->country); ?></td>
									<td><?php echo e($visitor->clicks); ?></td>
								</tr>
							<?php endforeach; ?>
							<?php else: ?>
							<tr><td colspan="3">Belum ada Pengunjung</td></tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>