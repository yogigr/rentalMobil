<?php $__env->startSection('title', 'Tambah Pengguna'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li><a href="/admin/user">Pengguna</a></li>
<li class="active">Tambah</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6">
		<div class="box box-solid">
			<div class="box-body">

				<?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger">
		                <ul>
		                    <?php foreach($errors->all() as $error): ?>
		                        <li><?php echo e($error); ?></li>
		                    <?php endforeach; ?>
		                </ul>
		            </div>
		        <?php endif; ?>

				<form method="post" action="<?php echo e(url('admin/user')); ?>">
					<?php echo e(csrf_field()); ?>

					<div class="form-group <?php echo e($errors->has('user_name') ? 'has-error' : ''); ?>">
						<label>Nama Lengkap</label>
						<input type="text" name="user_name" value="<?php echo e(old('user_name')); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('user_email') ? 'has-error' : ''); ?>">
						<label>Email</label>
						<input type="text" name="user_email" value="<?php echo e(old('user_email')); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('user_password') ? 'has-error' : ''); ?>">
						<label>Password</label>
						<input type="password" name="user_password" value="<?php echo e(old('user_password')); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('user_password_confirmation') ? 'has-error' : ''); ?>">
						<label>Konfirmasi Password</label>
						<input type="password" name="user_password_confirmation" value="<?php echo e(old('user_password_confirmation')); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<i class="fa fa-save"></i> Simpan
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>