<?php $__env->startSection('title', 'Pengaturan'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="active">Pengaturan</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<div class="row">
	<div class="col-md-12">
		<div class="box box-solid">
			<div class="box-body">

				<?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger">
		                <ul>
		                    <?php foreach($errors->all() as $error): ?>
		                        <li><?php echo e($error); ?></li>
		                    <?php endforeach; ?>
		                </ul>
		            </div>
		        <?php endif; ?>

				<form method="post" action="<?php echo e(url('admin/config')); ?>">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('patch')); ?>

					<div class="row">
						<div class="col-sm-12">
							<h4>Pengaturan Aplikasi</h4>
							<hr>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>App Name</label>
								<input type="text" name="app_name" value="<?php echo e(config('app.name')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>Environtment</label>
								<select class="form-control" name="app_env">
									<option value="local" <?php echo e(config('app.env') == 'local' ? 'selected' : ''); ?>>Local</option>
									<option value="production" <?php echo e(config('app.env') == 'production' ? 'selected' : ''); ?>>Production</option>
								</select>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>Debug</label>
								<select class="form-control" name="app_debug">
									<option value="0" <?php echo e(config('app.debug') == false ? 'selected' : ''); ?>>False</option>
									<option value="1" <?php echo e(config('app.debug') == true ? 'selected' : ''); ?>>True</option>
								</select>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>App URL</label>
								<input type="text" name="app_url" value="<?php echo e(config('app.url')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>Timezone</label>
								<input type="text" name="app_timezone" value="<?php echo e(config('app.timezone')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>Localization</label>
								<select class="form-control" name="app_locale">
									<option value="id" <?php echo e(config('app.locale') == 'id' ? 'selected' : ''); ?>>Indonesia</option>
									<option value="en" <?php echo e(config('app.locale') == 'en' ? 'selected' : ''); ?>>English</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<h4>Pengaturan Email</h4>
							<hr>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>Driver</label>
								<input type="text" name="mail_driver" value="<?php echo e(config('mail.driver')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>Host</label>
								<input type="text" name="mail_host" value="<?php echo e(config('mail.host')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group">
								<label>Port</label>
								<input type="text" name="mail_port" value="<?php echo e(config('mail.port')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label>Username</label>
								<input type="text" name="mail_username" value="<?php echo e(config('mail.username')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label>Password</label>
								<input type="text" name="mail_password" value="<?php echo e(config('mail.password')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label>From Address</label>
								<input type="text" name="mail_from_address" value="<?php echo e(config('mail.from.address')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group">
								<label>From Name</label>
								<input type="text" name="mail_from_name" value="<?php echo e(config('mail.from.name')); ?>" class="form-control"
								autocomplete="off">
							</div>
						</div>
					</div>
					<hr>
					<div class="form-group">
						<button type="submit" class="btn btn-primary btn-flat">
							<i class="fa fa-save"></i> Update
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>