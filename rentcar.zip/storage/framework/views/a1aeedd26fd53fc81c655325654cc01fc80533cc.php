<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin.css')); ?>">
    <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="hold-transition <?php echo e(!Auth::check() ? 'login-page' : 'skin-blue sidebar-mini'); ?>">
    <?php if(!Auth::check()): ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php else: ?>
    <div class="wrapper">
        <?php echo $__env->make('layouts.admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts.admin-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content-wrapper">
            <section class="content-header">
                <h1>
                    <?php echo $__env->yieldContent('title'); ?>
                    <small><?php echo $__env->yieldContent('description'); ?></small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                </ol>
            </section>
            <section class="content container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </div>
        <footer class="main-footer">
            <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name')); ?></a>.</strong> All rights reserved.
        </footer>
    </div>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>