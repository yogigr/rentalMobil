<?php $__env->startSection('title', 'Edit Paket Mobil'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li><a href="/admin/car">Paket Mobil</a></li>
<li class="active">Edit</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6">
		<div class="box box-solid">
			<div class="box-body">

				<?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger">
		                <ul>
		                    <?php foreach($errors->all() as $error): ?>
		                        <li><?php echo e($error); ?></li>
		                    <?php endforeach; ?>
		                </ul>
		            </div>
		        <?php endif; ?>

				<form method="post" action="<?php echo e(url('admin/car/'.$car->id)); ?>" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('PATCH')); ?>

					<div class="form-group <?php echo e($errors->has('car_name') ? 'has-error' : ''); ?>">
						<label>Merk dan Tipe Mobil</label>
						<input type="text" name="car_name" value="<?php echo e($car->name); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('car_description') ? 'has-error' : ''); ?>">
						<label>Deskripsi</label>
						<textarea rows="6" name="car_description" class="form-control" autocomplete="off"><?php echo e($car->description); ?></textarea>
					</div>
					<div class="form-group <?php echo e($errors->has('car_price') ? 'has-error' : ''); ?>">
						<label>Harga</label>
						<input type="text" name="car_price" value="<?php echo e($car->price); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('car_image') ? 'has-error' : ''); ?>">
						<label>Upload Photo</label>
						<input type="file" name="car_image" class="form-control">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<i class="fa fa-save"></i> Update
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>