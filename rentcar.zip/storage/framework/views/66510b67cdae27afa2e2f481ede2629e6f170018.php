<!--cars-->
<section class="section section-lg pt-lg-0 mt--200">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-12">
        <div class="row row-grid">
          <?php if($cars->count() > 0): ?>
          <?php foreach($cars as $car): ?>
          <div class="col-lg-4 mb-5">
            <div class="card card-lift--hover shadow border-0">
              <img class="card-img-top" src="<?php echo e($car->getImage()); ?>" alt="<?php echo e(config('app.name').'-'.$car->name); ?>">
              <div class="card-body py-5">
                <h6 class="text-primary text-uppercase"><?php echo e($car->name); ?></h6>
                <p class="description mt-3">Harga Rp <?php echo e($car->getPrice()); ?></p>
                <a href="#" class="btn btn-primary mt-4">Booking</a>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php else: ?>
          <div class="col-sm-12">
            Belum ada Paket
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>