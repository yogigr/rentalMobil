<header class="main-header">
    <a href="<?php echo e(url('admin/dashboard')); ?>" class="logo">
        <span class="logo-mini"><?php echo e(config('app.name')); ?></span>
        <span class="logo-lg"><?php echo e(config('app.name')); ?></span>
    </a>
    <nav class="navbar navbar-static-top" role="navigation">
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo e(url('/')); ?>" target="_blank"><i class="fa fa-eye"></i> Lihat Web</a></li>
            </ul>
        </div>
    </nav>
</header>