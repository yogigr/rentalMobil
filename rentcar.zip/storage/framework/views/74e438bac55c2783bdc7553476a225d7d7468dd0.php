<?php $__env->startSection('title', 'How'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="active">How</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<div class="row">
	<div class="col-md-12">
		<div class="box box-solid">
			<div class="box-header bg-gray">
				<div class="row">
					<div class="col-sm-6">
						<a href="<?php echo e(url('admin/how/create')); ?>" class="btn btn-primary btn-flat">
							<i class="fa fa-plus"></i>
							Tambah How
						</a>
					</div>
					<div class="col-sm-6">
						<form id="searchForm" method="get" action="<?php echo e(url('admin/how')); ?>" class="input-group" style="max-width: 300px">
							<div class="input-group-addon bg-light-blue"><i class="fa fa-search"></i></div>
							<input type="text" name="query" class="form-control" value="<?php echo e(request('query')); ?>" 
							placeholder="Cari" autocomplete="off">
						</form>
					</div>
				</div>
			</div>
			<div class="box-body table-responsive no-padding">
				<table class="table table-hover table-bordered table-striped">
					<thead class="bg-gray">
						<tr>
							<th style="width: 20px">Nomor Urut</th>
							<th>Icon</th>
							<th>Title</th>
							<th style="max-width: 350px">Deskripsi</th>
							<th>Ditambahkan</th>
							<th>Options</th>
						</tr>
					</thead>
					<tbody>
						<?php if($hows->count() > 0 ): ?>
						<?php foreach($hows as $how): ?>
						<tr>
							<td><?php echo e($how->order_number); ?></td>
							<td><?php echo $how->icon; ?></td>
							<td><?php echo e($how->title); ?></td>
							<td style="max-width: 350px"><?php echo e($how->description); ?></td>
							<td><?php echo e($how->user->name); ?></td>
							<td>
								<div class="btn-group">
									<a href="<?php echo e(url('admin/how/'.$how->id)); ?>" class="btn btn-info btn-xs">
										<i class="fa fa-file-text-o"></i>
									</a>
									<a href="<?php echo e(url('admin/how/'.$how->id.'/edit')); ?>" class="btn btn-xs btn-warning">
										<i class="fa fa-edit"></i>
									</a>
									<button class="btn btn-xs btn-danger delete-how-btn"
									url="<?php echo e(url('admin/how/'.$how->id)); ?>">
										<i class="fa fa-trash"></i>
									</button>
								</div>
							</td>
						</tr>
						<?php endforeach; ?>
						<?php else: ?>
						<tr><td colspan="5"><?php echo e(request('query') ? 'tidak ditemukan' : 'data belum ada'); ?></td></tr>
						<?php endif; ?>
					</tbody>
				</table>
			</div>
			<div class="box-footer bg-gray text-right">
				<?php echo e($hows->links()); ?>

			</div>
		</div>
	</div>
</div>

<form id="deleteHowForm" method="post" action>
	<?php echo e(csrf_field()); ?>

	<?php echo e(method_field('delete')); ?>

</form>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<script>
	$(function(){
		$('body').on('click', '.delete-how-btn', function(){

			if (confirm('Apakah yakin hapus?')) {
				var url = $(this).attr('url');
				$('#deleteHowForm').attr('action', url);
				$('#deleteHowForm').submit();
			}

			return false;
		});
	});
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
	.pagination {
		margin: 0;
	}

	.o-img {
		max-width: 50px;
	}

	@media (max-width: 500px) {
		#searchForm {
	    	float: left !important;
	  	}
	}

	@media (min-width: 501px) {
	 	#searchForm {
	    	float: right !important;
	  	}
	}
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>