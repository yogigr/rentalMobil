<?php $__env->startSection('title', 'Lihat How'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li><a href="/admin/how">How</a></li>
<li class="active">show</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<div class="row">
	<div class="col-md-12">
		<div class="box box-solid">
			<div class="box-header">
				<a href="<?php echo e(url('admin/how/'.$how->id.'/edit')); ?>" class="btn btn-warning btn-flat">
					<i class="fa fa-edit"></i> Edit
				</a>
				<button class="btn btn-danger btn-flat delete-how-btn">
					<i class="fa fa-trash"></i> Hapus 
				</button>
			</div>
			<div class="box-body">
				<div class="table-responsive">
					<table class="table table-bordered">
						<body>
							<tr>
								<th>Nomor Urut</th>
								<td><?php echo e($how->order_number); ?></td>
							</tr>
							<tr>
								<th>Icon</th>
								<td><?php echo $how->icon; ?></td>
							</tr>
							<tr>
								<th>Title/Judul</th>
								<td><?php echo e($how->title); ?></td>
							</tr>
							<tr>
								<th>Ditambahkan</th>
								<td><?php echo e($how->user->name); ?></td>
							</tr>
							<tr>
								<th>TGL Dibuat</th>
								<td><?php echo e($how->created_at); ?></td>
							</tr>
							<tr>
								<th>TGL Diupdate</th>
								<td><?php echo e($how->updated_at); ?></td>
							</tr>
							<tr>
								<td colspan="2">
									<h4>Deskripsi</h4>
									<?php echo e($how->description); ?>

								</td>
							</tr>
						</body>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<form id="deleteHowForm" method="post" action>
	<?php echo e(csrf_field()); ?>

	<?php echo e(method_field('delete')); ?>

</form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
	$(function(){
		$('body').on('click', '.delete-how-btn', function(){

			if (confirm('Apakah yakin hapus?')) {
				var url = $(this).attr('url');
				$('#deleteHowForm').attr('action', url);
				$('#deleteHowForm').submit();
			}

			return false;
		});
	});
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>