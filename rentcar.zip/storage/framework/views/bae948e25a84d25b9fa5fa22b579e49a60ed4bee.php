<?php $__env->startSection('title', 'Edit Why'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li><a href="/admin/why">Why</a></li>
<li class="active">Edit</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6">
		<div class="box box-solid">
			<div class="box-body">

				<?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger">
		                <ul>
		                    <?php foreach($errors->all() as $error): ?>
		                        <li><?php echo e($error); ?></li>
		                    <?php endforeach; ?>
		                </ul>
		            </div>
		        <?php endif; ?>

				<form method="post" action="<?php echo e(url('admin/why/'.$why->id)); ?>">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('patch')); ?>

					<div class="form-group <?php echo e($errors->has('why_order_number') ? 'has-error' : ''); ?>">
						<label>Nomor Urut</label>
						<input type="number" name="why_order_number" value="<?php echo e($why->order_number); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('why_title') ? 'has-error' : ''); ?>">
						<label>Title/Judul</label>
						<input type="text" name="why_title" value="<?php echo e($why->title); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('why_description') ? 'has-error' : ''); ?>">
						<label>Deskripsi</label>
						<textarea rows="6" name="why_description" class="form-control" autocomplete="off"><?php echo e($why->description); ?></textarea>
					</div>
					<div class="form-group <?php echo e($errors->has('why_icon') ? 'has-error' : ''); ?>">
						<label>Icon</label>
						<input type="text" name="why_icon" value="<?php echo e($why->icon); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<i class="fa fa-save"></i> Update
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>