<?php $__env->startSection('title', 'Lihat Pengguna'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li><a href="/admin/user">Pengguna</a></li>
<li class="active">show</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-error alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<div class="row">
	<div class="col-md-12">
		<div class="box box-solid">
			<div class="box-header">
				<a href="<?php echo e(url('admin/user/'.$user->id.'/edit')); ?>" class="btn btn-warning btn-flat">
					<i class="fa fa-edit"></i> Edit
				</a>
				<button class="btn btn-danger btn-flat delete-user-btn">
					<i class="fa fa-trash"></i> Hapus 
				</button>
			</div>
			<div class="box-body">
				<div class="table-responsive">
					<table class="table table-bordered">
						<body>
							<tr>
								<th>Nama Lengkap</th>
								<td><?php echo e($user->name); ?></td>
							</tr>
							<tr>
								<th>Email</th>
								<td><?php echo e($user->email); ?></td>
							</tr>
							<tr>
								<th>TGL Dibuat</th>
								<td><?php echo e($user->created_at); ?></td>
							</tr>
							<tr>
								<th>TGL Diupdate</th>
								<td><?php echo e($user->updated_at); ?></td>
							</tr>
						</body>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<form id="deleteUserForm" method="post" action>
	<?php echo e(csrf_field()); ?>

	<?php echo e(method_field('delete')); ?>

</form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
	$(function(){
		$('body').on('click', '.delete-user-btn', function(){

			if (confirm('Apakah yakin hapus?')) {
				var url = $(this).attr('url');
				$('#deleteUserForm').attr('action', url);
				$('#deleteUserForm').submit();
			}

			return false;
		});
	});
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>