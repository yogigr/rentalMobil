<?php $__env->startSection('title', 'Kontak'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li class="active">Kontak</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	<?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<div class="row">
	<div class="col-md-12">
		<div class="box box-solid">
			<div class="box-body">

				<?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger">
		                <ul>
		                    <?php foreach($errors->all() as $error): ?>
		                        <li><?php echo e($error); ?></li>
		                    <?php endforeach; ?>
		                </ul>
		            </div>
		        <?php endif; ?>

				<form method="post" action="<?php echo e(url('admin/contact')); ?>">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('patch')); ?>

					<div class="row">
						<div class="col-sm-4">
							<div class="form-group <?php echo e($errors->has('nama_perusahaan') ? 'has-error' : ''); ?>">
								<label>Nama Perusahaan</label>
								<input type="text" name="nama_perusahaan" value="<?php echo e($contact->nama_perusahaan); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
								<label>Email</label>
								<input type="text" name="email" value="<?php echo e($contact->email); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group <?php echo e($errors->has('deskripsi_pendek') ? 'has-error' : ''); ?>">
								<label>Deskripsi Pendek</label>
								<input type="text" name="deskripsi_pendek" value="<?php echo e($contact->deskripsi_pendek); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group <?php echo e($errors->has('deskripsi') ? 'has-error' : ''); ?>">
								<label>Deskripsi Perusahaan</label>
								<textarea name="deskripsi" 
								class="form-control" rows="6"><?php echo e($contact->deskripsi); ?></textarea>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group <?php echo e($errors->has('alamat') ? 'has-error' : ''); ?>">
								<label>Alamat</label>
								<textarea name="alamat" 
								class="form-control" rows="6"><?php echo e($contact->alamat); ?></textarea>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group <?php echo e($errors->has('hari_kerja') ? 'has-error' : ''); ?>">
								<label>Hari Kerja</label>
								<input type="text" name="hari_kerja" value="<?php echo e($contact->hari_kerja); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group <?php echo e($errors->has('jam_kerja') ? 'has-error' : ''); ?>">
								<label>Jam Kerja</label>
								<input type="text" name="jam_kerja" value="<?php echo e($contact->jam_kerja); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-4">
							<div class="form-group <?php echo e($errors->has('telp1') ? 'has-error' : ''); ?>">
								<label>Telp 1</label>
								<input type="text" name="telp1" value="<?php echo e($contact->telp1); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group <?php echo e($errors->has('telp2') ? 'has-error' : ''); ?>">
								<label>Telp 2</label>
								<input type="text" name="telp2" value="<?php echo e($contact->telp2); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
						<div class="col-sm-4">
							<div class="form-group <?php echo e($errors->has('telp3') ? 'has-error' : ''); ?>">
								<label>Telp 3</label>
								<input type="text" name="telp3" value="<?php echo e($contact->telp3); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group <?php echo e($errors->has('facebook') ? 'has-error' : ''); ?>">
								<label>Facebook</label>
								<input type="text" name="facebook" value="<?php echo e($contact->facebook); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-group <?php echo e($errors->has('instagram') ? 'has-error' : ''); ?>">
								<label>Instagram</label>
								<input type="text" name="instagram" value="<?php echo e($contact->instagram); ?>"
								class="form-control" autocomplete="off">
							</div>
						</div>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary btn-flat">
							<i class="fa fa-save"></i> Update
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>