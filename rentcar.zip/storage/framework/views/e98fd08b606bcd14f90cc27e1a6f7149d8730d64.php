<?php $__env->startSection('title', 'Lupa Password'); ?>
<!-- Main Content -->
<?php $__env->startSection('content'); ?>

<div class="login-box">
    <div class="login-logo">
        <a href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name')); ?></a>
    </div>
    <div class="login-box-body">
        <p class="login-box-msg">Lupa Password</p>

        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form role="form" method="POST" action="<?php echo e(url('/password/email')); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="form-group has-feedback <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Email">
                <i class="fa fa-envelope form-control-feedback"></i>
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-primary btn-block btn-flat">
                    Kirim Link Reset Password
                </button>
            </div>
        </form>
        <a href="<?php echo e(url('login')); ?>">Login?</a><br>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>