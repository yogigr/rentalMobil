<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/front.css')); ?>">
</head>
<body>
    <?php echo $__env->make('layouts.front-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('layouts.front-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--WA BTN-->
    <a href="https://api.whatsapp.com/send?phone=62<?php echo e(substr(str_replace(' ', '', $contact->telp1), 1)); ?>" 
    class="whatsapp-float" target="_blank">
        <i class="fa fa-whatsapp whatsapp-float-icon"></i>
    </a>
    <script src="<?php echo e(asset('js/front.js')); ?>"></script>
</body>
</html>