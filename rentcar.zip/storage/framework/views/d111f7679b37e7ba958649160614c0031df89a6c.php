<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Nirwanatrans</title>
  <!-- Favicon -->
  <link href="#" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/argon.css')); ?>">
</head>

<body>
  <header class="header-global">
    <nav id="navbar-main" class="navbar navbar-main navbar-expand-lg navbar-transparent navbar-light headroom">
      <div class="container">
        <a class="navbar-brand mr-lg-5" href="index.html">
          NIRWANATRANS
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbar_global">
          <div class="navbar-collapse-header">
            <div class="row">
              <div class="col-6 collapse-brand">
                <a href="index.html">
                  NIRWANATRANS
                </a>
              </div>
              <div class="col-6 collapse-close">
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
                  <span></span>
                  <span></span>
                </button>
              </div>
            </div>
          </div>
          <ul class="navbar-nav navbar-nav-hover align-items-lg-center">
            <li class="nav-item"><a class="nav-link" href="paket.html">Paket Sewa</a></li>
            <li class="nav-item"><a class="nav-link" href="prosedur.html">Prosedur</a></li>
            <li class="nav-item"><a class="nav-link" href="kontak.html">Kontak Kami</a></li>
          </ul>
          <ul class="navbar-nav align-items-lg-center ml-lg-auto">
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://www.facebook.com/creativetim" target="_blank" data-toggle="tooltip" title="Like us on Facebook">
                <i class="fa fa-facebook-square"></i>
                <span class="nav-link-inner--text d-lg-none">Facebook</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://www.instagram.com/creativetimofficial" target="_blank" data-toggle="tooltip" title="Follow us on Instagram">
                <i class="fa fa-instagram"></i>
                <span class="nav-link-inner--text d-lg-none">Instagram</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://twitter.com/creativetim" target="_blank" data-toggle="tooltip" title="Follow us on Twitter">
                <i class="fa fa-twitter-square"></i>
                <span class="nav-link-inner--text d-lg-none">Twitter</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://github.com/creativetimofficial/argon-design-system" target="_blank" data-toggle="tooltip" title="Star us on Github">
                <i class="fa fa-github"></i>
                <span class="nav-link-inner--text d-lg-none">Github</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  <main>
    <div class="position-relative mb-lg-5">
      <!-- shape Hero -->
      <!--intro-->
      <section class="section section-lg section-shaped pb-250">
        <div class="shape shape-style-1 shape-default">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </div>
        <div class="container py-lg-md d-flex mt-lg-5">
          <div class="col px-0">
            <div class="row">
              <div class="col-lg-6">
                <h1 class="display-3  text-white">NIRWANATRANS
                  <span>Rental Mobil Bogor</span>
                </h1>
                <p class="lead  text-white">
                  Sewa mobil khusus Matic. <br>Harga mulai dari 300 ribuan per hari
                </p>
                <div class="btn-wrapper">
                  <a href="#" class="btn btn-info btn-icon mb-3 mb-sm-0">
                    <span class="btn-inner--text">Booking Sekarang</span>
                  </a>
                </div>
              </div>
              <div class="col-lg-6">
                <img src="<?php echo e(asset('images/cars/intro-vehicles.png')); ?>" class="img-fluid">
              </div>
            </div>
          </div>
        </div>
        <!-- SVG separator -->
        <div class="separator separator-bottom separator-skew">
          <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
            <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
          </svg>
        </div>
      </section>
      <!-- 1st Hero Variation -->
    </div>

    <!--cars-->
    <section class="section section-lg pt-lg-0 mt--200">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-12">
            <div class="row row-grid">
              <div class="col-lg-4">
                <div class="card card-lift--hover shadow border-0">
                  <img class="card-img-top" src="<?php echo e(asset('images/cars/Honda-Brio-Satya-E-CVT.jpg')); ?>" alt="Card image cap">
                  <div class="card-body py-5">
                    <h6 class="text-primary text-uppercase">Honda Brio Satya E CVT</h6>
                    <p class="description mt-3">Harga Rp 300.000</p>
                    <a href="#" class="btn btn-primary mt-4">Booking</a>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="card card-lift--hover shadow border-0">
                  <img class="card-img-top" src="<?php echo e(asset('images/cars/Mitsubishi-Xpander-Sport.jpg')); ?>" alt="Card image cap">
                  <div class="card-body py-5">
                    <h6 class="text-success text-uppercase">Mitsubishi Xpander Sport</h6>
                    <p class="description mt-3">Harga Rp 300.000</p>
                    <a href="#" class="btn btn-success mt-4">Booking</a>
                  </div>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="card card-lift--hover shadow border-0">
                  <img class="card-img-top" src="<?php echo e(asset('images/cars/Daihatsu-Sigra-1.2-R-Deluxe.jpg')); ?>" alt="Card image cap">
                  <div class="card-body py-5">
                    <h6 class="text-warning text-uppercase">Daihatsu Sigra 1.2 R Deluxe</h6>
                    <p class="description mt-3">Harga 300.000</p>
                    <a href="#" class="btn btn-warning mt-4">Booking</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- why us -->
    <section class="section pb-0 bg-gradient-warning">
      <div class="container">
        <div class="row row justify-content-center text-center">
          <div class="col-lg-8">
            <h2 class="text-white">Kenapa Harus Memilih Kami</h2>
            <p class="text-white">
              Kami mengedepankan Pelayanan yang baik dan ramah, Kualitas kendaraan yang selalu dalam kondisi baik, serta dukungan tim kami yang responsive melayani pelanggan.
            </p>
          </div>
        </div>
        <div class="row row-grid align-items-center">
          <div class="col-md-6 order-lg-2 ml-lg-auto">
            <div class="position-relative pl-md-5">
              <img src="<?php echo e(asset('images/web/ill-2.svg')); ?>" class="img-center img-fluid">
            </div>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="d-flex px-3">
              <div>
                <div class="icon icon-lg icon-shape bg-gradient-white shadow rounded-circle text-primary">
                  <i class="fa fa-handshake-o text-primary"></i>
                </div>
              </div>
              <div class="pl-4">
                <h4 class="display-3 text-white">Service</h4>
                <p class="text-white">
                  Pelanggan adalah bagian terpenting. Pelayanan yang baik kami utamakan untuk memanjakan pelanggan.
                </p>
              </div>
            </div>
            <div class="card shadow shadow-lg--hover mt-5">
              <div class="card-body">
                <div class="d-flex px-3">
                  <div>
                    <div class="icon icon-shape bg-gradient-success rounded-circle text-white">
                      <i class="fa fa-car"></i>
                    </div>
                  </div>
                  <div class="pl-4">
                    <h5 class="title text-success">Quality</h5>
                    <p>
                      Armada kendaraan mobil kami lengkap, selalu dalam kondisi baik dan layak untuk kenyamanan dan keamanan perjalanan pelanggan.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="card shadow shadow-lg--hover mt-5">
              <div class="card-body">
                <div class="d-flex px-3">
                  <div>
                    <div class="icon icon-shape bg-gradient-warning rounded-circle text-white">
                      <i class="fa fa-headphones"></i>
                    </div>
                  </div>
                  <div class="pl-4">
                    <h5 class="title text-warning">Support</h5>
                    <p>
                      Dukungan penuh dari Tim yang responsive memenuhi kebutuhan pelanggan sekitar informasi Tempat Wisata, Kuliner dan Hotel.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- SVG separator -->
      <div class="separator separator-bottom separator-skew zindex-100">
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
        </svg>
      </div>
    </section>
    
    <!-- How it works -->
    <section class="section section-lg">
      <div class="container">
        <div class="row justify-content-center text-center mb-3">
          <div class="col-lg-8">
            <h2 class="display-3">Alur Prosedur Penyewaan</h2>
          </div>
        </div>
        <div class="row">
          <div class="col">

            <!--1-->
            <div class="card bg-gradient-info shadow-lg border-0 mb-3">
              <div class="p-5">
                <div class="row align-items-center">
                  <div class="col-lg-10">
                    <h5 class="text-white">Calon Penyewa menghubungi kami terlebih dahulu</h5>
                    <p class="text-white mt-2">
                      Hubungi kami lewat WhatsApp, Sms, Telpon dengan nomor yang tertera di web Nirwanatrans atau boleh datang langsung ke kantor kami. kami akan cek ketersediaan mobil dan meminta data alamat calon penyewa terlebih dahulu.
                    </p>
                  </div>
                  <div class="col-lg-2 ml-lg-auto text-right">
                    <i class="fa fa-whatsapp fa-3x text-white"></i>
                  </div>
                </div>
              </div>
            </div>

            <!--2-->
            <div class="card bg-gradient-warning shadow-lg border-0 mb-3">
              <div class="p-5">
                <div class="row align-items-center">
                  <div class="col-lg-10">
                    <h4 class="text-white">Transfer booking fee</h4>
                    <p class="text-white mt-2">
                      Calon Penyewa wajib melakukan Transfer Booking Fee sebesar Rp 100.000
                    </p>
                  </div>
                  <div class="col-lg-2 ml-lg-auto text-right">
                    <i class="fa fa-dollar fa-3x text-white"></i>
                  </div>
                </div>
              </div>
            </div>

            <!--3-->
            <div class="card bg-gradient-default shadow-lg border-0 mb-3">
              <div class="p-5">
                <div class="row align-items-center">
                  <div class="col-lg-10">
                    <h4 class="text-white">Tim kami melakukan survey ke tempat tinggal calon penyewa</h4>
                    <p class="text-white mt-2">
                      Kami datang ke tempat / alamat calon penyewa, dan meminta fotokopi KK, KTP, SIM pengemudi, dan jaminan lainnya. 
                      Prosedur ini hanya berlaku untuk penyewaan lepas kunci / tanpa supir.
                    </p>
                  </div>
                  <div class="col-lg-2 ml-lg-auto text-right">
                    <i class="fa fa-male fa-3x text-white"></i>
                  </div>
                </div>
              </div>
            </div>

            <!--4-->
            <div class="card bg-gradient-success shadow-lg border-0 mb-3">
              <div class="p-5">
                <div class="row align-items-center">
                  <div class="col-lg-10">
                    <h4 class="text-white">Serah Terima Mobil / Penjemputan</h4>
                    <p class="text-white mt-2">
                      Serah terima mobil bagi penyewaan lepas kunci, atau penjemputan bagi penyewaan dengan supir, sekaligus pelunasan.
                    </p>
                  </div>
                  <div class="col-lg-2 ml-lg-auto text-right">
                    <i class="fa fa-car fa-3x text-white"></i>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>

    <!--Contact-->
    <section class="section section-lg bg-gradient-default">
      <div class="container">
        <div class="row text-center justify-content-center">
          <div class="col-lg-10">
            <h2 class="display-3 text-white">Kontak Kami</h2>
            <p class="lead text-white">
              Jangan ragu untuk menghubungi kami perihal booking / mengajukan pertanyaan sekitar rental mobil kami 
            </p>
          </div>
        </div>
        <div class="row row-grid mt-5">
          <div class="col-lg-4 text-center text-md-left">
            <div class="icon icon-lg icon-shape bg-gradient-white shadow rounded-circle text-primary">
              <i class="fa fa-map-marker text-primary"></i>
            </div>
            <h5 class="text-white mt-3">Alamat</h5>
            <p class="text-white mt-3">
              <strong>NIRWANATRANS</strong><br>
              Jl. Pelita Jaya 2 No. 36 Kedung Jaya<br>
              Cimanggu Bogor<br>
            </p>
          </div>
          <div class="col-lg-4 text-center">
            <div class="icon icon-lg icon-shape bg-gradient-white shadow rounded-circle text-primary">
              <i class="fa fa-briefcase text-primary"></i>
            </div>
            <h5 class="text-white mt-3">Jam Kerja</h5>
            <p class="text-white mt-3">
              Senin s/d Sabtu<br>
              Jam 8.00 s/d 17.00 WIB
            </p>
          </div>
          <div class="col-lg-4 text-center text-md-right">
            <div class="icon icon-lg icon-shape bg-gradient-white shadow rounded-circle text-primary">
              <i class="fa fa-whatsapp text-primary"></i>
            </div>
            <h5 class="text-white mt-3">WhatsApp/Sms/Telp</h5>
            <p class="text-white mt-3">
              0813 1564 6885<br>
              0813 2000 2056<br>
              0818 100 211<br>
            </p>
          </div>
        </div>
      </div>
      <!-- SVG separator -->
      <div class="separator separator-bottom separator-skew zindex-100">
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
        </svg>
      </div>
    </section>

  </main>
  <footer class="footer has-cards">
    <div class="container">
      <div class="row row-grid align-items-center my-md">
        <div class="col-lg-6">
          <h3 class="text-primary font-weight-light mb-2">Thank you for supporting us!</h3>
          <h4 class="mb-0 font-weight-light">Let's get in touch on any of these platforms.</h4>
        </div>
        <div class="col-lg-6 text-lg-center btn-wrapper">
          <a target="_blank" href="https://twitter.com/creativetim" class="btn btn-neutral btn-icon-only btn-twitter btn-round btn-lg" data-toggle="tooltip" data-original-title="Follow us">
            <i class="fa fa-twitter"></i>
          </a>
          <a target="_blank" href="https://www.facebook.com/creativetim" class="btn btn-neutral btn-icon-only btn-facebook btn-round btn-lg" data-toggle="tooltip" data-original-title="Like us">
            <i class="fa fa-facebook-square"></i>
          </a>
          <a target="_blank" href="https://dribbble.com/creativetim" class="btn btn-neutral btn-icon-only btn-dribbble btn-lg btn-round" data-toggle="tooltip" data-original-title="Follow us">
            <i class="fa fa-dribbble"></i>
          </a>
          <a target="_blank" href="https://github.com/creativetimofficial" class="btn btn-neutral btn-icon-only btn-github btn-round btn-lg" data-toggle="tooltip" data-original-title="Star on Github">
            <i class="fa fa-github"></i>
          </a>
        </div>
      </div>
      <hr>
      <div class="row align-items-center justify-content-md-between">
        <div class="col">
          <div class="copyright">
            &copy; 2018
            <a href="index.html">NIRWANATRANS</a>
          </div>
        </div>
      </div>
    </div>
  </footer>

  <!--WA BTN-->
  <a href="https://api.whatsapp.com/send?phone=6281315646885&amp;text=test" class="whatsapp-float" target="_blank">
    <i class="fa fa-whatsapp whatsapp-float-icon"></i>
  </a>

  <script src="<?php echo e(asset('js/app.js')); ?>"></script>
  <script src="<?php echo e(asset('js/argon.js')); ?>"></script>
</body>

</html>