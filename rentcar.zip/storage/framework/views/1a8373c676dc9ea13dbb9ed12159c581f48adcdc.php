<?php $__env->startSection('title', 'Tambah How'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<li><a href="/admin/how">How</a></li>
<li class="active">Tambah</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-6">
		<div class="box box-solid">
			<div class="box-body">

				<?php if(count($errors) > 0): ?>
		            <div class="alert alert-danger">
		                <ul>
		                    <?php foreach($errors->all() as $error): ?>
		                        <li><?php echo e($error); ?></li>
		                    <?php endforeach; ?>
		                </ul>
		            </div>
		        <?php endif; ?>

				<form method="post" action="<?php echo e(url('admin/how')); ?>">
					<?php echo e(csrf_field()); ?>

					<div class="form-group <?php echo e($errors->has('how_order_number') ? 'has-error' : ''); ?>">
						<label>Nomor Urut</label>
						<input type="number" name="how_order_number" value="<?php echo e(old('how_order_number')); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('how_title') ? 'has-error' : ''); ?>">
						<label>Title/Judul</label>
						<input type="text" name="how_title" value="<?php echo e(old('how_title')); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group <?php echo e($errors->has('how_description') ? 'has-error' : ''); ?>">
						<label>Deskripsi</label>
						<textarea rows="6" name="how_description" class="form-control" autocomplete="off"><?php echo e(old('how_description')); ?></textarea>
					</div>
					<div class="form-group <?php echo e($errors->has('how_icon') ? 'has-error' : ''); ?>">
						<label>Icon</label>
						<input type="text" name="how_icon" value="<?php echo e(old('how_icon')); ?>" class="form-control" autocomplete="off">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary">
							<i class="fa fa-save"></i> Simpan
						</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

	<style>
		.box-solid .box-body {
			padding: 20px;
		}
	</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>