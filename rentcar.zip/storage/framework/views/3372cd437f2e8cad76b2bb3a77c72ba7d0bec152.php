<section class="section section-lg">
  <div class="container">
    <div class="row justify-content-center text-center mb-3">
      <div class="col-lg-8">
        <?php if(Route::currentRouteName() == 'home'): ?>
        <h2 class="display-3">Alur Prosedur Penyewaan</h2>
        <?php endif; ?>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <?php $colors = ['bg-gradient-info', 'bg-gradient-warning', 'bg-gradient-default', 'bg-gradient-success']; ?>
        <?php if($hows->count() > 0): ?>
          <?php $num = 0 ?>
          <?php foreach($hows as $how): ?>
            <div class="card <?php echo e($colors[$num]); ?> shadow-lg border-0 mb-3">
              <div class="p-5">
                <div class="row align-items-center">
                  <div class="col-lg-10">
                    <h5 class="text-white"><?php echo e($how->title); ?></h5>
                    <p class="text-white mt-2">
                      <?php echo e($how->description); ?>

                    </p>
                  </div>
                  <div class="col-lg-2 ml-lg-auto text-right">
                    <?php echo $how->icon; ?>

                  </div>
                </div>
              </div>
            </div>
            <?php $num++ ?>
          <?php endforeach; ?>
        <?php else: ?>
        Belum ada data
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>